from modules.views.GameOverView import GameOverView
from modules.views.GameStartView import GameStartView
from modules.views.SwitchLevelView import SwitchLevelView
from modules.views.GameLevelView import GameLevelView
from modules.views.AbstractView import AbstractView
from modules.views.ViewManager import ViewManager
